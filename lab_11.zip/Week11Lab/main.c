//
//  main.c 
//  Week 11 
//
//  Created by Ashley Coleman on 7/5/18.
//  Copyright © 2018 Ashley Coleman. All rights reserved.
//

#include "core.h"

#ifndef TEST
int main(int argc, const char * argv[]) {
    return core_main(argc, argv);
}
#endif
