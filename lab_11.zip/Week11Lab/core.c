//
//  core.c
//  Week11 
//
//  Created by Ashley Coleman on 7/5/18.
//  Copyright © 2018 Ashley Coleman. All rights reserved.
//

#include <stdlib.h>
#include <string.h>

#include "core.h"

#include "rectangle.h"
#include "triangle.h"

int core_main(int argc, const char * argv[]) {
    return 0;
}

